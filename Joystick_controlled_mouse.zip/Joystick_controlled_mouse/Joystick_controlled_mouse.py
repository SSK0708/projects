import mouse, sys
import time
import serial

mouse.FAILSAFE=False
ArduinoSerial=serial.Serial('com7',9600)
time.sleep(1)

while 1:
    data=str(ArduinoSerial.readline().decode('ascii'))
    (x,y,z)=data.split("😊")
    (X,Y,Z)=mouse.get_position()
    (x,y)=(int(x),int(y))
    mouse.move(X+x,Y-y)
    if '1' in Z:
        mouse.click(button="left")

